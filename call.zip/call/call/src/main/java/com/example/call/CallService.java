package com.example.call;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CallService {

    @Autowired
    private CallRepository callRepository;

    public Call saveCall(Call call) {
        return callRepository.save(call);
    }

    public List<Call> getAllCalls() {
        return callRepository.findAll();
    }

    public Optional<Call> getCallById(String id) {
        return callRepository.findById(id);
    }

    public Optional<Call> updateCall(String id, Call callDetails) {
        return callRepository.findById(id).map(existingCall -> {
            existingCall.setSubject(callDetails.getSubject());
            existingCall.setDirection(callDetails.getDirection());
            existingCall.setCallStatus(callDetails.getCallStatus());
            existingCall.setStartTime(callDetails.getStartTime());
            existingCall.setDuration(callDetails.getDuration());
            existingCall.setTicket(callDetails.getTicket());
            existingCall.setContactName(callDetails.getContactName());
            existingCall.setPriority(callDetails.getPriority());
            existingCall.setCallOwner(callDetails.getCallOwner());
            existingCall.setDescription(callDetails.getDescription());
            return callRepository.save(existingCall);
        });
    }

    public boolean deleteCall(String id) {
        return callRepository.findById(id).map(call -> {
            callRepository.delete(call);
            return true;
        }).orElse(false);
    }
}
