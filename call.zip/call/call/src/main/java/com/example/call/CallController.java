package com.example.call;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/calls")
@CrossOrigin (origins="http://localhost:3000")
public class CallController {

    @Autowired
    private CallService callService;

    // Create a new call
    @PostMapping
    public ResponseEntity<Call> createCall(@RequestBody Call call) {
        Call newCall = callService.saveCall(call);
        return new ResponseEntity<>(newCall, HttpStatus.CREATED);
    }


    // Get all calls
    @GetMapping
    public ResponseEntity<List<Call>> getAllCalls() {
        List<Call> calls = callService.getAllCalls();
        return new ResponseEntity<>(calls, HttpStatus.OK);
    }

    // Get a call by ID
    @GetMapping("/{id}")
    public ResponseEntity<Call> getCallById(@PathVariable String id) {
        Optional<Call> call = callService.getCallById(id);
        return call.map(ResponseEntity::ok)
                   .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Update a call by ID
    @PutMapping("/{id}")
    public ResponseEntity<Call> updateCall(@PathVariable String id, @RequestBody Call callDetails) {
        Optional<Call> updatedCall = callService.updateCall(id, callDetails);
        return updatedCall.map(ResponseEntity::ok)
                          .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Delete a call by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCall(@PathVariable String id) {
        boolean deleted = callService.deleteCall(id);
        if (deleted) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
