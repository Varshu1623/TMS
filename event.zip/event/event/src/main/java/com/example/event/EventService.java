package com.example.event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EventService {

    @Autowired
    private EventRepository eventRepository;

    public Event saveEvent(Event event) {
        return eventRepository.save(event);
    }

    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }

    public Optional<Event> getEventById(String id) {
        return eventRepository.findById(id);
    }

    public Optional<Event> updateEvent(String id, Event eventDetails) {
        return eventRepository.findById(id).map(existingEvent -> {
            existingEvent.setSubject(eventDetails.getSubject());
            existingEvent.setCategory(eventDetails.getCategory());
            existingEvent.setStatus(eventDetails.getStatus());
            existingEvent.setStartTime(eventDetails.getStartTime());
            existingEvent.setDuration(eventDetails.getDuration());
            existingEvent.setTicket(eventDetails.getTicket());
            existingEvent.setContactName(eventDetails.getContactName());
            existingEvent.setPriority(eventDetails.getPriority());
            existingEvent.setEventOwner(eventDetails.getEventOwner());
            existingEvent.setSetReminder(eventDetails.getSetReminder());
            existingEvent.setDescription(eventDetails.getDescription());
            return eventRepository.save(existingEvent);
        });
    }

    public boolean deleteEvent(String id) {
        return eventRepository.findById(id).map(event -> {
            eventRepository.delete(event);
            return true;
        }).orElse(false);
    }
}
